import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-body-map',
  standalone: true,
  templateUrl: './body-map.component.html',
  styleUrls: [],
  imports: [CommonModule],
})
export class BodyMapComponent {
  @Output() bodyPartSelected = new EventEmitter<string>();

  selectedPart: string = '';
  isFrontView: boolean = true;

  selectPart(part: string) {
    this.selectedPart = part;
    this.bodyPartSelected.emit(part);
  }

  toggleView() {
    this.isFrontView = !this.isFrontView;
    this.selectedPart = ''; // reset selected part when switching
  }
}
