import { Component, HostListener, Renderer2, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
  searchQuery: string = '';
  users = [
    { id: 1, name: 'Yousef El-Arbi', email: 'El-Arbi@example.com', role: 'EHS' },
    { id: 2, name: 'Ayman Nasri', email: 'Nasri@example.com', role: 'EHS' },
    { id: 3, name: 'Amina Elahlo', email: 'Elahlo@example.com', role: 'Profil' },
    { id: 3, name: 'Rachid Hadouti', email: 'Hadouti@example.com', role: 'Profil' },
    { id: 4, name: 'Reda Naciri', email: 'Naciri@example.com', role: 'Admin' }
  ];
  roles = ['Admin', 'EHS', 'Profil'];
  dropdownOpen = false;
  sidebarOpen = false;

  constructor(private renderer: Renderer2, private el: ElementRef) { }

  filteredUsers() {
    return this.users.filter(user =>
      user.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  openUserModal() {
    console.log("Open add user modal");
  }

  editUser(user: any) {
    console.log("Edit user:", user);
  }

  deleteUser(userId: number) {
    this.users = this.users.filter(user => user.id !== userId);
    console.log("Deleted user with ID:", userId);
  }

  updateUserRole(user: any) {
    console.log(`Updated role for ${user.name} to ${user.role}`);
  }

  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  toggleSidebar() {
    this.sidebarOpen = !this.sidebarOpen;
    const sidebar = this.el.nativeElement.querySelector('.sidebar');
    if (this.sidebarOpen) {
      this.renderer.addClass(sidebar, 'open');
    } else {
      this.renderer.removeClass(sidebar, 'open');
    }
  }

  @HostListener('document:click', ['$event'])
  closeSidebar(event: Event) {
    if (this.sidebarOpen) {
      const sidebar = this.el.nativeElement.querySelector('.sidebar');
      const hamburger = this.el.nativeElement.querySelector('.hamburger');
      if (!sidebar.contains(event.target as Node) && !hamburger.contains(event.target as Node)) {
        this.renderer.removeClass(sidebar, 'open');
        this.sidebarOpen = false;
      }
    }
  }

  logout() {
    console.log("Logging out...");
  }
}
